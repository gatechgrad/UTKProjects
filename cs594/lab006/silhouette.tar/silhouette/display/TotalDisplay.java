package silhouette.display;

import silhouette.shapes.*;

public class TotalDisplay {
  
/*
  public void notify (Object obj) {
    if (obj.getDepth() == SilCanvas.FeedbackDepth)
      feedbackObjects.add(obj)
    else
      onlyFeedbackObjects = false;
      remove this from observer status
  }

  public void redisplay(Graphics g) {
    if (onlyFeedbackObjects == true)
      feedbackShortcut()
    else
      total redisplay
      onlyFeedbackObjects = true;
      register this as an observer
    feedbackObjects.clear();

  }

  public void feedbackShortcut() {
    for each object in feedbackObjects do
      erase object's old image
      draw object's new image
  }
*/
} 