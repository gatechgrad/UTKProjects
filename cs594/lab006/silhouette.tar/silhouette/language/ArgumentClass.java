package silhouette.language;

public class ArgumentClass {
  String str;
  boolean isName;

  // constructor
  public ArgumentClass(String s, boolean b) {
    str = s;
    isName = b;
  }

}
