package silhouette.interactors;

import java.awt.event.*;

public interface SilInputEvent {
  public boolean equals(InputEvent event);
}
