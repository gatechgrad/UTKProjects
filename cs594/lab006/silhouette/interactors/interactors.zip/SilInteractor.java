package silhouette.interactors;

import java.awt.*;
import java.awt.Event;
import javax.swing.*;
import java.awt.event.*;
import java.util.Vector;
import java.util.EventListener;
import java.util.LinkedList;
import java.util.Iterator;
import silhouette.shapes.*;

/**
 * An abstract base class for creating responses to input events. An
 * interactor handles a series of related events that are required to
 * implement a behavior, such as a move behavior, a text editing behavior,
 * or a selection behavior. Once an interactor starts running, it receives
 * all input events until it indicates that it is done.
 * <p>
 * Conceptually an interactor is a finite state machine with a series
 * of states and a series of transitions between states based on input events.
 * The implementor of an interactor is responsible for setting an interactor's
 * state variable (via the setState method) based on the input events that
 * are received. There are two special states, a START state and a STOP
 * state. When an interactor is in the START state, it is not executing but
 * is ready to accept input events if an input event matches its start event.
 * When an interactor is in the STOP state, it is indicating that it is done
 * executing and no longer wants to receive input events. The Silhouette
 * event handler will then automatically switch the interactor back to the
 * START state. If an interactor is in any other state, then it is currently
 * executing and wants to receive all input events from the Silhouette event
 * handler.
 * <p>
 * A Silhouette interactor implements the MouseListener, MouseMotionListener,
 * and KeyListener interfaces. The methods in these interfaces are the
 * methods that a programmer should override in order to implement the
 * interactor. The Silhouette object that the interactor is currently
 * operating on can be found in the selectedObject field and the canvas
 * that contains the selected object can be retrieved from the source field
 * of the event.
 */

abstract public class SilInteractor
  implements MouseListener, MouseMotionListener, KeyListener {
  /**
   * a constant that denotes the interactor's start state
   */
  public static final int START = -1; // start state

  /**
   * a constant that denotes the interactor's stop state
   */
  public static final int STOP = -2;  // stop state

  /**
   * a constant that denotes the interactor's running state
   */
  public static final int RUNNING = -3;  // running state
  
  /**
   * The interactor's current state
   */
  int state = START;

  /**
   * The object that the interactor is currently operating on
   */
  Object selectedObject = null;

  /**
   * Default constructor function does nothing.
   */
  public SilInteractor () {}

  /**
   * Get the interactor's state
   */
  public int getState () {
    return state;
  }

  /**
   * Set the interactor's state
   */
  public SilInteractor setState (int newState) {
    state = newState;
    return this;
  }

  /**
   * Get the selected object
   */
   public Object getSelectedObject() {
    return selectedObject;
   }

  /**
   * Set the selected object
   */
  public SilInteractor setSelectedObject (Object newSelectedObject) {
    selectedObject = newSelectedObject;
    return this;
  }

  /**
   * Start the interactor by placing it in the given state with the
   * given selected object
   */
  public void startInteractor(int beginState, Object targetObject) {
    state = beginState;
    selectedObject = targetObject;
    SilEventHandler.getSilEventHandler().setActiveInteractor (this);
  }

  /**
   * Invoked when the mouse has been clicked on a shape
   */
  public void mouseClicked(MouseEvent e) {}

  /**
   * Invoked when a mouse button has been pressed on a shape
   */
  public void mousePressed(MouseEvent e) {}

  /**
   * Invoked when a mouse button has been released on a shape
   */
  public void mouseReleased(MouseEvent e) {}

  /**
   * Invoked when the mouse enters a Silhouette canvas. In the future
   * this method may be extended to handle the case when the mouse enters
   * a shape.
   */
  public void mouseEntered(MouseEvent e) {}

  /**
   * Invoked when the mouse leaves a Silhouette canvas. In the future
   * this method may be extended to handle the case when the mouse leaves
   * a shape.
   */
  public void mouseExited(MouseEvent e) {}

  /**
   * Invoked when a mouse button is pressed on a shape and then dragged
   */
  public void mouseDragged(MouseEvent e) {}

  /**
   * Invoked when a mouse button has been moved on a shape (with no buttons
   * down)
   */
  public void mouseMoved(MouseEvent e) {}

  /**
   * Invoked when a key is typed
   */
  public void keyTyped(KeyEvent e) {}

  /**
   * Invoked when a key is pressed
   */
  public void keyPressed(KeyEvent e) {}

  /**
   * Invoked when a key is released
   */
  public void keyReleased(KeyEvent e) {}
}

