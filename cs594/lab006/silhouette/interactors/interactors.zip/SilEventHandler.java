package silhouette.interactors;

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Vector;
import java.util.Stack;
import java.util.Hashtable;
import java.util.LinkedList;
import java.util.Iterator;
import silhouette.shapes.*;

/**************************************************************************
 *
 * The SilEventHandler class distributes Java events to the
 * Silhouette Interactors. If an interactor is already running, then
 * any event is passed to that interactor. If an interactor is not
 * running, then the event handler gets a stack of objects that
 * contain the event. The topmost object on the stack will be the leaf
 * object that contains the event. The next object on the stack will
 * be the composite object that contains the leaf object and so. The
 * bottommost object on the stack will be the canvas that contains the
 * event. The event handler runs through the interactor list of
 * each object on the stack and gives each interactor the chance to
 * handle the event. If an interactor handles the event, the event
 * handler makes the interactor be the active interactor and returns.
 * An interactor indicates that it has handled the event by changing
 * its state to something other than START. If the interactor wants to
 * The interactor will then receive all events until it enters the
 * STOP state. The implementor of the interactor is responsible for
 * setting the interactor's state to STOP.
 *
 *************************************************************************/

public class SilEventHandler {

  /**
   * constants that tell the handleEvent method which method to call
   */
  private static final int MousePressed = 1;
  private static final int MouseReleased = 2;
  private static final int MouseClicked = 3;
  private static final int MouseEntered = 4;
  private static final int MouseExited = 5;
  private static final int MouseMoved = 6;
  private static final int MouseDragged = 7;
  private static final int KeyTyped = 8;
  private static final int KeyPressed = 9;
  private static final int KeyReleased = 10;

  /**
   * Stack of shapes that contain an event. This stack could be declared
   * locally but then it would be constantly allocated and de-allocated.
   * By declaring it as an instance variable we prevent constant allocations
   * and de-allocations.
   */
  protected Stack foundShapes = new Stack();

  /**
   * The interactor that is currently receiving events
   */
  protected SilInteractor ActiveInteractor = null;

  /**
   * The singleton instance of the Silhouette event handler
   */
  static protected SilEventHandler eventHandler = new SilEventHandler();

  /**
   * The hash table that contains each object's list of interactors
   */
  protected Hashtable interactorTable = new Hashtable();

  /**
   * Saves the last mouse position so that a key event can determine
   * where the mouse is
   */
  protected int mouseX;
  protected int mouseY;

  /**
   * The silhouette interactor handler should be a singleton so prevent it
   * from being called by the application
   */
  protected SilEventHandler() {}

  /**
   * Return the singleton instance of the silhouette event handler
   */
  static public SilEventHandler getSilEventHandler() {
    return eventHandler;
  }

  /**
   * Add an interactor to an object's interactor list
   */
  public void addInteractor(Object object, SilInteractor interactor) {
    LinkedList interactorList = (LinkedList)interactorTable.get(object);
    if (interactorList == null) {
      interactorList = new LinkedList();
      interactorTable.put(object, interactorList);
    }
    interactorList.addLast(interactor);
  }

  /**
   * Remove an interactor from an object's interactor list
   */
  public void removeInteractor(Object object, SilInteractor interactor) {
    LinkedList interactorList = (LinkedList)interactorTable.get(object);
    if (interactorList != null) {
      interactorList.remove(interactor);
    }
  }

  /** Translate mouse coordinates to coordinate system of the selected
   *  object's parent
   */
  void translateMouseCoordinates(MouseEvent event, SilInteractor inter) {
    Object obj = inter.getSelectedObject();
    if (obj instanceof SilPanel)
	return;   // mouse coordinates already correct
    else {
	SilShape selection = (SilShape)obj;
	SilPanel panel = (SilPanel)event.getSource();
	SilShape stoppingObj = (SilShape)panel.getCanvas();
	CompositeShape parent = (CompositeShape)selection.getParent();

	while (parent != stoppingObj) {
	    event.translatePoint(-(int)parent.getLeft(),
				 -(int)parent.getTop());
	    parent = (CompositeShape)parent.getParent();
	}
    }
  }

  /**
   * Dispatch the event to the appropriate method in the interactor
   */
  protected void handleEvent(SilInteractor inter, InputEvent event,
                                int methodName) {
    // translate mouse coordinates to coordinate system of the selected
    // object's parent
    if (event instanceof MouseEvent)
      translateMouseCoordinates((MouseEvent)event, inter);

    switch (methodName) {
    case MousePressed:
      inter.mousePressed((MouseEvent)event);
      break;
    case MouseReleased:
    	inter.mouseReleased((MouseEvent)event);
      break;
    case MouseClicked:
    	inter.mouseClicked((MouseEvent)event);
      break;
    case MouseEntered:
    	inter.mouseEntered((MouseEvent)event);
      break;
    case MouseExited:
    	inter.mouseExited((MouseEvent)event);
      break;
    case MouseDragged:
    	inter.mouseDragged((MouseEvent)event);
      break;

    case MouseMoved:
    	inter.mouseMoved((MouseEvent)event);
      break;
    case KeyTyped:
    	inter.keyTyped((KeyEvent)event);
      break;
    case KeyPressed:
    	inter.keyPressed((KeyEvent)event);
      break;
    case KeyReleased:
    	inter.keyReleased((KeyEvent)event);
      break;

    }
  }

  /**
   * Select an interactor to handle the given event
   */
  public void selectSilInteractor(InputEvent event, int methodName) {
    // if the event is a mouse event, save the mouse's (x,y) position
    // so that a subsequent key event can access this position
    if (event instanceof MouseEvent) {
      MouseEvent e = (MouseEvent)event;
      mouseX = e.getX();
      mouseY = e.getY();
    }
    SilPanel panel = (SilPanel)event.getSource();

    // if an interactor is currently receiving events, send the event to
    // that interactor. In order to send the event to the interactor, it
    // is necessary to go through the interactor's list of event handlers
    // and find the event handler that will handle the event. Once the
    // event is handled, check the active interactor's state. If the
    // stop state has been reached, set the ActiveInteractor variable to
    // null and reset the interactor's state to start.
    if (ActiveInteractor != null) {
      handleEvent(ActiveInteractor, event, methodName);
      if (ActiveInteractor.getState() == SilInteractor.STOP) {
        ActiveInteractor.setState(SilInteractor.START);
        ActiveInteractor = null;
      }
      panel.repaint();
    }
    // if there is not an interactor currently receiving an event, try to
    // find an interactor that will handle the event. If the event is a mouse
    // motion event we just
    // ignore it because: 1) an interactor generally does not start with
    // a mouse motion event, and 2) so many mouse motion events get
    // generated that a lot of time would be wasted checking to see whether
    // an interactor should start on a mouse motion event
    else if ((methodName == SilEventHandler.MouseMoved)
            || (methodName == SilEventHandler.MouseDragged))
        return;
    else {
      SilInteractor candidateInteractor;
      boolean eventHandled = false;

      // Get a stack of shapes that contain the event.
      foundShapes.removeAllElements();
      panel.getCanvas().findShapes(mouseX, mouseY, foundShapes);

      // Starting with the topmost shape, examine each shape's interactor
      // list to determine if has an interactor that handles the event. If
      // such an interactor is found, send the event to the interactor. If
      // the interactor immediately stops, reset the interactor's state to
      // start. However, if the interactor wants to continue to operate (its
      // state will not equal stop), then make the interactor the
      // ActiveInteractor.
      while (!eventHandled && !foundShapes.empty()) {
	      Object candidateObject = foundShapes.pop();
        LinkedList interactorList =
                (LinkedList)interactorTable.get(candidateObject);
        if (interactorList != null) {
	        Iterator interIter = interactorList.iterator();
	        while (!eventHandled && interIter.hasNext()) {
            candidateInteractor = (SilInteractor)interIter.next();
	          candidateInteractor.setSelectedObject(candidateObject);
            handleEvent(candidateInteractor, event, methodName);
            switch (candidateInteractor.getState()) {
              case SilInteractor.START:
                  break;
              case SilInteractor.STOP:
		              panel.repaint();
		              candidateInteractor.setState(SilInteractor.START);
		              eventHandled = true;
		              break;
              default:
		              ActiveInteractor = candidateInteractor;
		              eventHandled = true;
		              panel.repaint();
                  break;
            }
	        }
	      }
	    }
	  }
  }

  /**
   * Tells the event handler to start sending events to the indicated
   * interactor
   */
  public void setActiveInteractor(SilInteractor inter) {
    ActiveInteractor = inter;
  }

  /**
   * Add event listeners to the canvas that call the silhouette interactor
   * handler.
   */
  public void addPanel(SilPanel c) {
    c.addMouseListener(new MouseAdapter() {

      public void mousePressed (MouseEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.MousePressed);
      }
      public void mouseReleased (MouseEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.MouseReleased);
      }
      public void mouseClicked (MouseEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.MouseClicked);
      }
   });
    c.addMouseMotionListener (new MouseMotionAdapter () {
      public void mouseMoved(MouseEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.MouseMoved);
      }
      public void mouseDragged(MouseEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.MouseDragged);
      }
    });
    c.addKeyListener (new KeyAdapter () {
      public void keyTyped(KeyEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.KeyTyped);
      }
      public void keyPressed(KeyEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.KeyPressed);
      }
      public void keyReleased(KeyEvent event) {
        SilEventHandler handler = SilEventHandler.getSilEventHandler();
	      handler.selectSilInteractor(event, SilEventHandler.KeyReleased);
      }
    });
  
}
}
